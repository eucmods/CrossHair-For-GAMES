package com.coringa.cmods.tekashi;

/*
 Creator By CoRingaModz, When you use Leave the credits with me, thanks for understanding, This and my telegram official, want to know more about me @CoRingaModzYT
*/

/*
Criador Por CoRingaModz, Ao usar Deixe os créditos comigo, obrigado pela compreensão, Este e meu telegrama oficial, querem saber mais sobre mim @CoRingaModzYT
*/


import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.util.TypedValue;
import android.view.View;
import android.content.Context;
import android.provider.Settings;
import android.net.Uri;
import android.os.Process;
import android.widget.Toast;

public class TekashiTeam extends Service {
    
    private WindowManager mWindowManager;
    private static LinearLayout cross;
    private static final String TAG = "CrossHair By CoRinga Modz";
    
    
    @Override
    public IBinder onBind(Intent intent) {
        throw new UnsupportedOperationException("Not yet implemented");
    }
    
    @Override
    public void onCreate() {
        super.onCreate();
        Toast.makeText(getApplicationContext(), (new Object() {
            int t;
            public String toString() {
                byte[] buf = new byte[23];
                t = 761072876;
                buf[0] = (byte) (t >>> 10);
                t = -592922573;
                buf[1] = (byte) (t >>> 22);
                t = -2094187676;
                buf[2] = (byte) (t >>> 13);
                t = -629617907;
                buf[3] = (byte) (t >>> 3);
                t = 1345243347;
                buf[4] = (byte) (t >>> 9);
                t = 1541846399;
                buf[5] = (byte) (t >>> 22);
                t = 1849813992;
                buf[6] = (byte) (t >>> 21);
                t = -234427379;
                buf[7] = (byte) (t >>> 20);
                t = 1103046747;
                buf[8] = (byte) (t >>> 7);
                t = 1865103598;
                buf[9] = (byte) (t >>> 24);
                t = -969323564;
                buf[10] = (byte) (t >>> 15);
                t = -281178060;
                buf[11] = (byte) (t >>> 7);
                t = 1593266381;
                buf[12] = (byte) (t >>> 6);
                t = 1237315689;
                buf[13] = (byte) (t >>> 18);
                t = -1690839735;
                buf[14] = (byte) (t >>> 2);
                t = 1201117788;
                buf[15] = (byte) (t >>> 6);
                t = 1622638231;
                buf[16] = (byte) (t >>> 15);
                t = 1505653455;
                buf[17] = (byte) (t >>> 1);
                t = -485625989;
                buf[18] = (byte) (t >>> 19);
                t = 1429602049;
                buf[19] = (byte) (t >>> 18);
                t = 999005132;
                buf[20] = (byte) (t >>> 6);
                t = -515232622;
                buf[21] = (byte) (t >>> 5);
                t = -1537684526;
                buf[22] = (byte) (t >>> 3);
                return new String(buf);
            }
        }.toString()), Toast.LENGTH_SHORT).show();
        CoRingaModzYT();
    }

    
    private void CoRingaModzYT() {
        cross = new LinearLayout(this);
        FrameLayout.LayoutParams fraLayoutParamsx = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        cross.setLayoutParams(fraLayoutParamsx);

        RelativeLayout hair = new RelativeLayout(this);
        RelativeLayout.LayoutParams hairr = new RelativeLayout.LayoutParams(dp(50), dp(50));
        hair.setBackgroundResource(R.drawable.aimcross);
        hair.setLayoutParams(hairr);

        cross.addView(hair);

        int flag;
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.N_MR1){
            flag = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        }
        else {
            flag = WindowManager.LayoutParams.TYPE_PHONE;
        }
        final WindowManager.LayoutParams params = new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,
                                                                                 WindowManager.LayoutParams.WRAP_CONTENT,flag, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                                                                                 PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.CENTER | Gravity.CENTER;
        params.x = 0;
        params.y = 0;
        mWindowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        mWindowManager.addView(cross, params);
        // cross.setVisibility(View.GONE);
    }

    public static void StartService(Context context){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
            context.startActivity(new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION",
                                             Uri.parse("package:" + context.getPackageName())));
            Process.killProcess(Process.myPid());
        } else {
            context.startService(new Intent(context, TekashiTeam.class));
        }
    }
    public static void StopService(Context context){
        context.stopService(new Intent(context, TekashiTeam.class));
        TekashiTeam.cross.setVisibility(View.GONE);
    }
    private int dp(int value){
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, getResources().getDisplayMetrics());
    }
}

